package de.menouer.santorini.infrastructure.console.main;

public class ConsoleMain {

	public void startGame() {
		// TODO Auto-generated method stub
		
	}

}
