package de.menouer.santorini.infrastructure.gui;

import de.menouer.santorini.businesslogic.contract.IGameService;
import de.menouer.santorini.businesslogic.contract.IGameView;
import de.menouer.santorini.businesslogic.contract.impl.GameServiceImpl;
import de.menouer.santorini.businesslogic.model.BoardPosition;
import de.menouer.santorini.businesslogic.model.EWorkerColor;
import de.menouer.santorini.businesslogic.model.GameBoard;
import de.menouer.santorini.businesslogic.model.GameBoardCell;
import de.menouer.santorini.businesslogic.model.Player;
import de.menouer.santorini.businesslogic.model.Players;
import de.menouer.santorini.infrastructure.gui.piece.PieceFigureFatory;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;

public class GameView implements IGameView {

	@FXML
	private GridPane gameBoardGridPane;

	@FXML
	private TextArea messageToPlayer;
	
	@FXML
	private FlowPane firstPlayerFlowPane;
	
	@FXML
	private FlowPane secondPlayerFlowPane;

	private IGameService gameService;

	public GameView() {
		Players players = getSelectPlayers();
		gameService = new GameServiceImpl(this);
		gameService.setPlayers(players.getCurrentPlayer(), players.getOtherPlayer());
	}

	private Players getSelectPlayers() {
		Player currentPlayer = new Player("Current", "Player", EWorkerColor.PURPLE);
		Player otherPlayer = new Player("Other", "Player", EWorkerColor.BLUE);
		return new Players(currentPlayer, otherPlayer);
	}

	public void setGameService(IGameService gameService) {
		this.gameService = gameService;
	}

	/**
	 * Initializes the controller class. This method is automatically called after
	 * the fxml file has been loaded.
	 */
	@FXML
	private void initialize() {
		onInitGameView();
	}

//	private void initStackPaneGameBoard() {
//		GameBoard gameBoard = gameService.getGameBoard();
//		GameBoardCell[][] cellsArray = gameBoard.getCellsArray();
//
//		int row = 0;
//		for (GameBoardCell[] columnsRow : cellsArray) {
//			for (int col = 0; col < columnsRow.length; col++) {
//				Image image = new Image(getClass().getResourceAsStream(String.format("/map-tiles/%d%d.png", row, col)));
//				ImageView cellImage = new ImageView(image);
//				StackPane stackPane = new StackPane();
//
//				// stackPane.getChildren().addAll(cellImage, b1, r, circle);
//				stackPane.getChildren().addAll(cellImage);
//
//				stackPane.setOnMouseClicked(handleBoardCellOnClick(stackPane));
//
//				stackPane.setOnMouseExited((MouseEvent e) -> {
//					System.out.println("Exited!");
//					stackPane.setStyle("-fx-border-color: transparent; ");
//				});
//
//				GridPane.setConstraints(stackPane, col++, row);
//				gameBoardGridPane.getChildren().add(stackPane);
//			}
//			row++;
//		}
//
//	}

	private EventHandler<MouseEvent> handleBoardCellOnClick(StackPane stackPane) {
		return (MouseEvent e) -> {
			System.out.println("StackPane Clicked!");
			stackPane.setStyle("-fx-border-color: #ff0000; ");

			BoardPosition selectedPosition = getBoardPositionFromMouseClickEvent(e);
			gameService.handleBoardPositionSelection(selectedPosition);
		};
	}

	private BoardPosition getBoardPositionFromMouseClickEvent(MouseEvent event) {
		Node node = (Node) event.getTarget();
		int row = GridPane.getRowIndex(node);
		int column = GridPane.getColumnIndex(node);
		return new BoardPosition(row, column);
	}

//	EventHandler<ActionEvent> buttonEventHandler(){
//	    return event -> {
//	        Node node = (Node) event.getTarget();
//	        int row = GridPane.getRowIndex(node);
//	        int column = GridPane.getColumnIndex(node);
//	    };
//	}

	@Override
	public void onInitGameView() {
		//initStackPaneGameBoard();
		initWorkersFlowPane();
	}

	private void initWorkersFlowPane() {
		Circle redWorker = PieceFigureFatory.createWorkerWithColor(Color.RED);
		Circle blueWorker = PieceFigureFatory.createWorkerWithColor(Color.BLUE);
		blueWorker.setOnMouseClicked(handleWorkerOnClick(blueWorker));
		firstPlayerFlowPane.getChildren().addAll(redWorker, blueWorker);
	}
	
	private EventHandler<MouseEvent> handleWorkerOnClick(Circle worker) {
		return (MouseEvent e) -> {
			System.out.println("Worker was clicked!");
			if (worker.getStrokeWidth() == 10) {
				worker.setStrokeWidth(0);
			} else {
				worker.setStrokeWidth(10);
			}
		};
	}

	@Override
	public void onPlayerMoveTargetPositionSelection() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onPlayerBuildingBlocSelection() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onPlayerBuildingBlocTargetPositionSelection() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onPlayerWorkerSelection(BoardPosition[] possibleMovePositions) {
		if (possibleMovePositions != null) {
			markPossibleMovePositions(possibleMovePositions);
		}
	}

	private void markPossibleMovePositions(BoardPosition[] possibleMovePositions) {
		// TODO Auto-generated method stub

	}

	@Override
	public void displayErrorMessage(String message) {
		messageToPlayer.setText(String.format("ERROR-MESSAGE: &s", message));
	}

	@Override
	public void displayInfoMessage(String message) {
		messageToPlayer.setText(String.format("INFO-MESSAGE: &s", message));
	}

}
