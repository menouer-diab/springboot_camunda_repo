package de.menouer.santorini.infrastructure.gui.main;

import java.io.IOException;

import de.menouer.santorini.infrastructure.gui.GameView;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class GuiMain extends Application {

	public void startGame(String[] args) {
		launch(args);
	}

    public GuiMain() {
    }

    @Override
    public void start(Stage stage) throws Exception {
        stage.setTitle("Santorini Game");
        stage.setOnCloseRequest(x -> {
            Platform.exit();
        });
        stage.setResizable(true);
        Parent settingsPane = FXMLLoader.load(getClass().getResource("/views/game-settings-view.fxml"));
		stage.setScene(new Scene(settingsPane));
        stage.show();
    }
    
    /**
     * creating a controller and calling set()-Methods
     */
    public void justeTest(Stage stage) {
    	try {
			FXMLLoader loader = FXMLLoader.load(getClass().getClassLoader().getResource("/views/game-view.fxml"));
			GameView g = new GameView();
			loader.setController(g);
			g.setGameService(null);
			
			Parent root = loader.load();
			Scene scene = new Scene(root);
			stage.setScene(scene);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

//    @FXML
//    protected void handleOnAnyButtonClicked(ActionEvent evt) {
//        Button button = (Button)evt.getSource();
//        final String buttonText = button.getText();
//    }

}
