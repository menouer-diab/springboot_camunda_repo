package de.menouer.santorini.infrastructure.gui;

import java.io.IOException;

import de.menouer.santorini.businesslogic.model.EWorkerColor;
import de.menouer.santorini.businesslogic.model.GameSettings;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class GameSettingsView {
	
	@FXML
	private GridPane settingsPane;
	
	@FXML
	private Button startGameButton;
	
	@FXML
	private TextField firstPlayerNameTxtField;
	
	@FXML
	private TextField secondPlayerNameTxtField;
	
	@FXML
	private RadioButton firstPlayerWorkerRedColorRdBtn;
	
	@FXML
	private RadioButton secondPlayerWorkerRedColorRdBtn;
	
	@FXML
	private RadioButton firstPlayerWorkerBlueColorRdBtn;
	
	@FXML
	private RadioButton secondPlayerWorkerBlueColorRdBtn;
	
	@FXML
	private Text validationErrorMessage;
	
	@FXML
	private void initialize() {
	}
	
	@FXML
	private void startGame() {
		try {
			
			GameSettings gameSettings = new GameSettings();
			gameSettings.setFirstPlayerName(firstPlayerNameTxtField.getText());
			gameSettings.setSecondPlayerName(secondPlayerNameTxtField.getText());
			
			String color1 = firstPlayerWorkerRedColorRdBtn.isSelected() ? "RED" : firstPlayerWorkerBlueColorRdBtn.isSelected()? "BLUE":"";
			String color2 = secondPlayerWorkerRedColorRdBtn.isSelected() ? "RED" : secondPlayerWorkerBlueColorRdBtn.isSelected()? "BLUE":"";
			
			gameSettings.setFirstPlayerWorkerColor(color1);
			gameSettings.setSecondPlayerWorkerColor(color2);
			
			if (!gameSettings.isValid()) {
				validationErrorMessage.setText("Settings entered are not valid!");
			} else {
				AnchorPane gamePane = FXMLLoader.load(getClass().getResource("/views/game-view-with-builder.fxml"));
				Stage stage = (Stage) settingsPane.getScene().getWindow();
				stage.setScene(new Scene(gamePane));
			}
			
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
