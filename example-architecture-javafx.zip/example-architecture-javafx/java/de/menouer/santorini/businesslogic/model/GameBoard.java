package de.menouer.santorini.businesslogic.model;

import java.util.stream.IntStream;

public class GameBoard {
	private static final int DIMENSION = 5;
	private GameBoardCell[][] cellsArray;
	
	public GameBoard() {
		cellsArray = new GameBoardCell[DIMENSION][DIMENSION];
		IntStream.range(0, DIMENSION-1).forEach(rowIndex -> populateRow(rowIndex));
	}

	private void populateRow(int rowIndex) {
		IntStream.range(0, DIMENSION-1).forEach(colIndex -> populateRowColumn(rowIndex, colIndex));
	}

	private GameBoardCell populateRowColumn(int rowIndex, int colIndex) {
		return cellsArray[rowIndex][colIndex] = new GameBoardCell(rowIndex, colIndex);
	}
	
	public GameBoardCell[][] getCellsArray() {
		return cellsArray;
	}
}
