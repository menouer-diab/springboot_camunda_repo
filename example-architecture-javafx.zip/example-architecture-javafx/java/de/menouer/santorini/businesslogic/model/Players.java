package de.menouer.santorini.businesslogic.model;

public class Players {
	
	private Player currentPlayer;
	private Player otherPlayer;
	
	public Players(Player currentPlayer, Player otherPlayer) {
		super();
		this.currentPlayer = currentPlayer;
		this.otherPlayer = otherPlayer;
	}

	public Player getCurrentPlayer() {
		return currentPlayer;
	}

	public Player getOtherPlayer() {
		return otherPlayer;
	}
	
}
