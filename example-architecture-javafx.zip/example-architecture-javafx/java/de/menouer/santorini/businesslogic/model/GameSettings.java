package de.menouer.santorini.businesslogic.model;

public class GameSettings {

	private String firstPlayerName;
	private String secondPlayerName;
	private String firstPlayerWorkerColor;
	private String secondPlayerWorkerColor;

	public void setFirstPlayerName(String name) {
		this.firstPlayerName = name;
	}

	public void setSecondPlayerName(String name) {
		this.secondPlayerName = name;
	}

	public void setFirstPlayerWorkerColor(String color) {
		this.firstPlayerWorkerColor = color;
	}

	public void setSecondPlayerWorkerColor(String color) {
		this.secondPlayerWorkerColor = color;
	}
	
	public boolean isValid() {
		if (firstPlayerName == null || firstPlayerName.length() == 0) {
			return false;
		}
		
		if (secondPlayerName == null || secondPlayerName.length() == 0) {
			return false;
		}
		
		if (firstPlayerWorkerColor == null || firstPlayerWorkerColor.length() == 0) {
			return false;
		}
		
		if (secondPlayerWorkerColor == null || secondPlayerWorkerColor.length() == 0) {
			return false;
		}
		
		if (firstPlayerName.equals(secondPlayerName)) {
			return false;
		}
		
		if (firstPlayerWorkerColor.equals(secondPlayerWorkerColor)) {
			return false;
		}
		
		return true;
		
	}

}
