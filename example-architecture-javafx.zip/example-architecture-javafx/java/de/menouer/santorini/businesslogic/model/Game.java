package de.menouer.santorini.businesslogic.model;

public class Game {
	
	private GameBoard gameBoard;
	private Player currentPlayer;
	private Player otherPlayer;
	private GameNextAction nextAction;
	
	public Game() {
		gameBoard = new GameBoard();
	}

	public GameBoard getGameBoard() {
		return gameBoard;
	}

	public void setCurrentPlayer(Player currentPlayer) {
		this.currentPlayer = currentPlayer;
	}

	public void setOtherPlayer(Player otherPlayer) {
		this.otherPlayer = otherPlayer;
	}

	public Player getCurrentPlayer() {
		return currentPlayer;
	}

	public Player getOtherPlayer() {
		return otherPlayer;
	}

	public GameNextAction getNextAction() {
		return nextAction;
	}

	public void setNextAction(GameNextAction nextAction) {
		this.nextAction = nextAction;
	}


}
