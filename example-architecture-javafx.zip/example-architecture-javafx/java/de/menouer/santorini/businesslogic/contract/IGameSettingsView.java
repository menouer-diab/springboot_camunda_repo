package de.menouer.santorini.businesslogic.contract;

public interface IGameSettingsView {
	void onPlayersSelection();
	void onStartGame();
}
