package de.menouer.santorini.businesslogic.contract;

import de.menouer.santorini.businesslogic.model.BoardPosition;

public interface IGameView {
	
	void onInitGameView();
		
	void onPlayerMoveTargetPositionSelection();
	
	void onPlayerBuildingBlocSelection();
	
	void onPlayerBuildingBlocTargetPositionSelection();

	void onPlayerWorkerSelection(BoardPosition[] possibleMovePositions);

	void displayErrorMessage(String message);

	void displayInfoMessage(String message);

}
