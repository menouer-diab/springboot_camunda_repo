package de.menouer.santorini.infrastructure.gui;

import de.menouer.santorini.businesslogic.contract.IGameService;
import de.menouer.santorini.businesslogic.contract.IGameView;
import de.menouer.santorini.businesslogic.contract.impl.GameServiceImpl;
import de.menouer.santorini.businesslogic.model.BoardPosition;
import de.menouer.santorini.businesslogic.model.EWorkerColor;
import de.menouer.santorini.businesslogic.model.GameBoard;
import de.menouer.santorini.businesslogic.model.GameBoardCell;
import de.menouer.santorini.businesslogic.model.Player;
import de.menouer.santorini.businesslogic.model.Players;
import de.menouer.santorini.infrastructure.gui.piece.PieceFigureFatory;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.TextArea;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.StrokeType;

public class GameView implements IGameView {

	@FXML
	private GridPane gameBoardGridPane;

	@FXML
	private TextArea messageToPlayer;
	
	@FXML
	private FlowPane firstPlayerFlowPane;
	
	@FXML
	private FlowPane secondPlayerFlowPane;

	private IGameService gameService;

	public GameView() {
		gameService = GameServiceImpl.getInstance();
		gameService.setGameView(this);
	}

	/**
	 * Initializes the controller class. This method is automatically called after
	 * the fxml file has been loaded.
	 */
	@FXML
	private void initialize() {
		onInitGameView();
	}

//	private void initStackPaneGameBoard() {
//		GameBoard gameBoard = gameService.getGameBoard();
//		GameBoardCell[][] cellsArray = gameBoard.getCellsArray();
//
//		int row = 0;
//		for (GameBoardCell[] columnsRow : cellsArray) {
//			for (int col = 0; col < columnsRow.length; col++) {
//				Image image = new Image(getClass().getResourceAsStream(String.format("/map-tiles/%d%d.png", row, col)));
//				ImageView cellImage = new ImageView(image);
//				StackPane stackPane = new StackPane();
//
//				// stackPane.getChildren().addAll(cellImage, b1, r, circle);
//				stackPane.getChildren().addAll(cellImage);
//
//				stackPane.setOnMouseClicked(handleBoardCellOnClick(stackPane));
//
//				stackPane.setOnMouseExited((MouseEvent e) -> {
//					System.out.println("Exited!");
//					stackPane.setStyle("-fx-border-color: transparent; ");
//				});
//
//				GridPane.setConstraints(stackPane, col++, row);
//				gameBoardGridPane.getChildren().add(stackPane);
//			}
//			row++;
//		}
//
//	}

	private EventHandler<MouseEvent> handleBoardCellOnClick(StackPane stackPane) {
		return (MouseEvent e) -> {
			System.out.println("StackPane Clicked!");
			stackPane.setStyle("-fx-border-color: #ff0000; ");

			BoardPosition selectedPosition = getBoardPositionFromMouseClickEvent(e);
			gameService.handleBoardPositionSelection(selectedPosition);
		};
	}

	private BoardPosition getBoardPositionFromMouseClickEvent(MouseEvent event) {
		Node node = (Node) event.getTarget();
		int row = GridPane.getRowIndex(node);
		int column = GridPane.getColumnIndex(node);
		return new BoardPosition(row, column);
	}

	@Override
	public void onInitGameView() {
		//initStackPaneGameBoard();
		initWorkersFlowPane(gameService.getCurrentPlayer(), firstPlayerFlowPane);
		initWorkersFlowPane(gameService.getOtherPlayer(), secondPlayerFlowPane);
	}

	private void initWorkersFlowPane(Player player, FlowPane playerFlowPane) {
		Circle firstWorker = PieceFigureFatory.createWorkerWithColor(Color.valueOf(player.getWorkerColor().name()));
		Circle secondWorker = PieceFigureFatory.createWorkerWithColor(Color.valueOf(player.getWorkerColor().name()));
		firstWorker.setOnMouseClicked(handleWorkerOnClick(player, firstWorker, 0));
		secondWorker.setOnMouseClicked(handleWorkerOnClick(player, secondWorker, 1));
		playerFlowPane.getChildren().addAll(firstWorker, secondWorker);
	}
	
	private EventHandler<MouseEvent> handleWorkerOnClick(Player player, Circle worker, int workerIndex) {
		return (MouseEvent e) -> {
			updateWorkerSelection(player, worker, workerIndex);
			gameService.handleWorkerSelection(player, workerIndex);
		};
	}

	private void updateWorkerSelection(Player player, Circle worker, int workerIndex) {
		if (!player.getWorker(workerIndex).isSelected()) {
			System.out.println("Worker was not selected!");
			worker.setStroke(Color.BLACK);
			worker.getStrokeDashArray().addAll(5.0, 5.0, 5.0, 5.0);
			worker.setStrokeWidth(3);
		} else {
			System.out.println("Worker was selected!");
			worker.getStrokeDashArray().clear();
			worker.setStrokeWidth(0);
		}
	}

	@Override
	public void onPlayerMoveTargetPositionSelection() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onPlayerBuildingBlocSelection() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onPlayerBuildingBlocTargetPositionSelection() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onPlayerWorkerSelection(BoardPosition[] possibleMovePositions) {
		if (possibleMovePositions != null) {
			markPossibleMovePositions(possibleMovePositions);
		}
	}

	private void markPossibleMovePositions(BoardPosition[] possibleMovePositions) {
		// TODO Auto-generated method stub

	}

	@Override
	public void displayErrorMessage(String message) {
		messageToPlayer.setText(String.format("ERROR-MESSAGE: &s", message));
	}

	@Override
	public void displayInfoMessage(String message) {
		messageToPlayer.setText(String.format("INFO-MESSAGE: &s", message));
	}

}
