package de.menouer.santorini.businesslogic.model;

public class Worker {
	
	private EWorkerColor color;
	private BoardPosition position;
	private boolean isSelected;

	public Worker(EWorkerColor workerColor) {
		color = workerColor;
	}
	
	public boolean isPlacedOnBoard() {
		return position != null;
	}
	
	public void setPosition(BoardPosition position) {
		this.position = position;
	}
	
	public EWorkerColor getColor() {
		return color;
	}

	public void setSelected(boolean status) {
		this.isSelected = status;
	}

	public boolean isSelected() {
		return isSelected;
	}

}
