package de.menouer.santorini.businesslogic.model;

public class PlayerMove {

}
