package de.menouer.santorini.businesslogic.model;

import java.util.Arrays;

public class Player {

	private final String playerName;
	private final EWorkerColor workerColor;
	private Worker[] workers;
	private BuildingBloc[] buildingBlocs;

	public Player(String playerName, EWorkerColor workerColor) {
		this.playerName = playerName;
		this.workerColor = workerColor;
		
		//workers
		workers = new Worker[]{new Worker(workerColor), new Worker(workerColor)};
	}
	
	public String getPlayerName() {
		return playerName;
	}

	public EWorkerColor getWorkerColor() {
		return workerColor;
	}

	public Worker[] getWorkers() {
		return workers;
	}

	public boolean owns(Worker worker) {
		return Arrays.stream(workers).anyMatch(w -> w == worker);
	}

	public Worker getSelectedWorker() {
		return Arrays.stream(workers).filter(worker -> worker.isSelected()).findFirst().get();
	}

	public boolean hasAllWorkersPlacedOnBoard() {
		// TODO Auto-generated method stub
		return false;
	}

	public Worker getWorker(int workerIndex) {
		return workers[workerIndex];
	}

}
