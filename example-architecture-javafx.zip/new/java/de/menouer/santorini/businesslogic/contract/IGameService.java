package de.menouer.santorini.businesslogic.contract;

import de.menouer.santorini.businesslogic.model.BoardPosition;
import de.menouer.santorini.businesslogic.model.GameBoard;
import de.menouer.santorini.businesslogic.model.GameSettings;
import de.menouer.santorini.businesslogic.model.Player;
import de.menouer.santorini.infrastructure.gui.GameSettingsView;
import de.menouer.santorini.infrastructure.gui.GameView;

public interface IGameService {
	
	void initGame();

	void startGame();

	BoardPosition[] getPossibleMovesForPlayer();

	void getPossibleBuildingBlocsForPlayer();

	void checkPlayerMove(Player currentPlayer, BoardPosition position);

	void checkPlayerSelectedBuildingBloc();

	GameBoard getGameBoard();

	Player getCurrentPlayer();
	
	Player getOtherPlayer();

	void handleBoardPositionSelection(BoardPosition selectedPosition);

	void setSettingsView(IGameSettingsView settingsView);

	void setGameView(IGameView gameView);

	void handleGameSettingsOnSubmit(GameSettings gameSettings);

	void handleWorkerSelection(Player player, int workerIndex);
	
}
