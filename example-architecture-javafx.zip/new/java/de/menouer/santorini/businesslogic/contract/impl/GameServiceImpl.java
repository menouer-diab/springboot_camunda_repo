package de.menouer.santorini.businesslogic.contract.impl;

import de.menouer.santorini.businesslogic.contract.IGameService;
import de.menouer.santorini.businesslogic.contract.IGameSettingsView;
import de.menouer.santorini.businesslogic.contract.IGameView;
import de.menouer.santorini.businesslogic.model.BoardPosition;
import de.menouer.santorini.businesslogic.model.Game;
import de.menouer.santorini.businesslogic.model.GameBoard;
import de.menouer.santorini.businesslogic.model.GameBoardCell;
import de.menouer.santorini.businesslogic.model.GameNextAction;
import de.menouer.santorini.businesslogic.model.GameSettings;
import de.menouer.santorini.businesslogic.model.Player;
import de.menouer.santorini.businesslogic.model.Worker;

public class GameServiceImpl implements IGameService {

	private Game game;
	private IGameView view;
	private IGameSettingsView settingsView;
	private static IGameService gameService;

	// private GameBoard gameBoard;

	private GameServiceImpl() {
		initGame();
	}

	private GameServiceImpl(IGameView view) {
		this();
		this.view = view;
	}

	public static synchronized IGameService getInstance() {
		if (gameService == null) {
			gameService = new GameServiceImpl();
		}
		return gameService;
	}

	public static synchronized IGameService getInstance(IGameView view) {
		if (gameService == null) {
			gameService = new GameServiceImpl(view);
		}
		return gameService;
	}

	@Override
	public void setSettingsView(IGameSettingsView settingsView) {
		this.settingsView = settingsView;
	}

	@Override
	public void setGameView(IGameView gameView) {
		this.view = gameView;
	}

	@Override
	public void initGame() {
		game = new Game();
	}

	@Override
	public void startGame() {
		// TODO Auto-generated method stub

	}

	@Override
	public BoardPosition[] getPossibleMovesForPlayer() {
		if (game.getNextAction() == GameNextAction.CHECK_WORKER_INITIAL_POSITION_SELECTION) {

		}

		if (game.getNextAction() == GameNextAction.CHECK_PLAYER_MOVE_POSITION_SELECTION) {

		}
		return null;
	}

	@Override
	public void getPossibleBuildingBlocsForPlayer() {
		// TODO Auto-generated method stub

	}

	@Override
	public void checkPlayerSelectedBuildingBloc() {
		// TODO Auto-generated method stub

	}

	public GameBoard getGameBoard() {
		return game.getGameBoard();
	}

	@Override
	public Player getCurrentPlayer() {
		return game.getCurrentPlayer();
	}

	@Override
	public Player getOtherPlayer() {
		return game.getOtherPlayer();
	}

	@Override
	public void checkPlayerMove(Player currentPlayer, BoardPosition position) {
		// TODO Auto-generated method stub

	}

	@Override
	public void handleBoardPositionSelection(BoardPosition selectedPosition) {
		switch (game.getNextAction()) {

		case CHECK_WORKER_TO_BE_MOVED_SELECTION:
			handleWorkerToBeMovedSelection(selectedPosition);
			break;

		case CHECK_WORKER_INITIAL_POSITION_SELECTION:
			handleWorkerInitialPositionSelection(selectedPosition);
			break;

		case CHECK_PLAYER_MOVE_POSITION_SELECTION:
			break;

		case CHECK_PLAYER_BUILDING_POSITION_SELECTION:
			break;

		default:
		}

	}

	private void handleWorkerInitialPositionSelection(BoardPosition selectedPosition) {
		GameBoard gameBoard = game.getGameBoard();
		GameBoardCell gameBoardCell = gameBoard.getCellsArray()[selectedPosition.getRow()][selectedPosition
				.getColumn()];
		int highestBuildingBlocLevel = gameBoardCell.getHighestBuildingBlocLevel();

		if (gameBoardCell.isFree() || highestBuildingBlocLevel == 1) {
			Player currentPlayer = game.getCurrentPlayer();
			Worker selectedWorker = currentPlayer.getSelectedWorker();
			selectedWorker.setSelected(false);
			selectedWorker.setPosition(selectedPosition);

			if (currentPlayer.hasAllWorkersPlacedOnBoard()) {

			} else {
				game.setNextAction(GameNextAction.CHECK_WORKER_TO_BE_MOVED_SELECTION);
			}

			view.displayInfoMessage("successful initial position selection for worker!");
			return;
		} else {
			view.displayErrorMessage("worker isn't allowed to be placed on a building-bloc level greater than 1!");
		}

	}

	private void handleWorkerToBeMovedSelection(BoardPosition selectedPosition) {
		GameBoard gameBoard = game.getGameBoard();
		GameBoardCell gameBoardCell = gameBoard.getCellsArray()[selectedPosition.getRow()][selectedPosition
				.getColumn()];
		Worker worker = gameBoardCell.getWorker();
		if (worker != null) {
			if (game.getCurrentPlayer().owns(worker)) {
				game.setNextAction(GameNextAction.CHECK_PLAYER_MOVE_POSITION_SELECTION);
				BoardPosition[] possibleMovesForPlayer = getPossibleMovesForPlayer();
				worker.setSelected(true);
				view.onPlayerWorkerSelection(possibleMovesForPlayer);
				view.displayInfoMessage("succesful Worker selection!");
			} else {
				view.displayErrorMessage("The worker you selected doesn't belong to the current player!");
			}
		} else {
			view.displayErrorMessage("there exists no worker on the selected board position!");
		}
	}

	@Override
	public void handleGameSettingsOnSubmit(GameSettings gameSettings) {
		if (isValid(gameSettings)) {
			game.setGameSettings(gameSettings);
			game.setCurrentPlayer(new Player(gameSettings.getFirstPlayerName(), gameSettings.getFirstPlayerWorkerColor()));
			game.setOtherPlayer(new Player(gameSettings.getSecondPlayerName(), gameSettings.getSecondPlayerWorkerColor()));
			settingsView.startGame();
		} else {
			settingsView.displayGameSettingsErrorMessage("Settings entered are not valid. Please set the settings again!");
		}
	}

	private boolean isValid(GameSettings gameSettings) {

		if (gameSettings.getFirstPlayerName() == null || gameSettings.getFirstPlayerName().length() == 0) {
			return false;
		}

		if (gameSettings.getSecondPlayerName() == null || gameSettings.getSecondPlayerName().length() == 0) {
			return false;
		}

		if (gameSettings.getFirstPlayerName().equals(gameSettings.getSecondPlayerName())) {
			return false;
		}

		if (gameSettings.getFirstPlayerWorkerColor().equals(gameSettings.getSecondPlayerWorkerColor())) {
			return false;
		}

		return true;

	}

	@Override
	public void handleWorkerSelection(Player player, int workerIndex) {
		Worker worker = player.getWorker(workerIndex);
		boolean currentStatus = worker.isSelected();
		worker.setSelected(!currentStatus);
	}

}
