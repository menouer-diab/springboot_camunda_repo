package de.menouer.santorini.infrastructure.gui;

import java.util.List;

import de.menouer.santorini.businesslogic.contract.IGameService;
import de.menouer.santorini.businesslogic.contract.IGameView;
import de.menouer.santorini.businesslogic.contract.impl.GameServiceImpl;
import de.menouer.santorini.businesslogic.model.BoardPosition;
import de.menouer.santorini.businesslogic.model.GameBoard;
import de.menouer.santorini.businesslogic.model.Player;
import de.menouer.santorini.businesslogic.model.Worker;
import de.menouer.santorini.infrastructure.gui.piece.PieceFigureFatory;
import de.menouer.santorini.infrastructure.gui.piece.WorkerGui;
import de.menouer.santorini.infrastructure.gui.player.PlayerGuiControls;
import de.menouer.santorini.infrastructure.gui.player.PlayersGui;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.TextArea;
import javafx.scene.effect.Effect;
import javafx.scene.effect.InnerShadow;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;

public class GameView implements IGameView {

//	private PlayerGuiControls firstPlayerGui;
//
//	private PlayerGuiControls secondPlayerGui;
	
	// private PlayerGuiControls[] playerGuis;
	
	private PlayersGui playersGui;

	@FXML
	private GridPane gameBoardGridPane;

	@FXML
	private TextArea messageToPlayer;

	@FXML
	private FlowPane firstPlayerFlowPane;

	@FXML
	private FlowPane secondPlayerFlowPane;

	private IGameService gameService;

	private StackPane[][] boardGridArray;

	public GameView() {
		gameService = GameServiceImpl.getInstance();
		gameService.setGameView(this);
		playersGui = new PlayersGui();
	}

	/**
	 * Initializes the controller class. This method is automatically called after
	 * the fxml file has been loaded.
	 */
	@FXML
	private void initialize() {
		onInitGameView();
	}

	@Override
	public void onInitGameView() {
		// initStackPaneGameBoard();
		initGameBoardArray();
		playersGui.initFirstPlayerGui(firstPlayerFlowPane);
		playersGui.initSecondPlayerGui(secondPlayerFlowPane);
		
		initWorkersFlowPane(gameService.getCurrentPlayer(), playersGui.getCurrentPlayerGui());
		initWorkersFlowPane(gameService.getOtherPlayer(), playersGui.getOtherPlayerGui());
	}
	
	private void initWorkersFlowPane(Player player, PlayerGuiControls playerGui) {
		WorkerGui firstWorker = PieceFigureFatory.createWorkerWithColor(Color.valueOf(player.getWorkerColor().name()),
				0);
		WorkerGui secondWorker = PieceFigureFatory.createWorkerWithColor(Color.valueOf(player.getWorkerColor().name()),
				1);

		firstWorker.setOnMouseClicked(handleWorkerOnClick(player, playerGui));
		secondWorker.setOnMouseClicked(handleWorkerOnClick(player, playerGui));
		FlowPane playerFlowPane = playerGui.getPlayerFlowPane();
		playerGui.setFirstWorker(firstWorker);
		playerGui.setSecondWorker(secondWorker);
		playerFlowPane.getChildren().addAll(firstWorker, secondWorker);
	}

	private void initGameBoardArray() {
		this.boardGridArray = new StackPane[GameBoard.DIMENSION][GameBoard.DIMENSION];
		int rowIndex = 0;
		int colIndex = 0;
		for (Node node : this.gameBoardGridPane.getChildren()) {
			boardGridArray[rowIndex][colIndex] = (StackPane)node;
			node.setOnMouseClicked(handleGameBoardPositionOnClick(new BoardPosition(rowIndex, colIndex)));
			
			colIndex++;
			if (colIndex == GameBoard.DIMENSION) {
				colIndex = 0;
				rowIndex++;
			}
		}
	}

	private EventHandler<? super MouseEvent> handleGameBoardPositionOnClick(BoardPosition boardPosition) {
		return (MouseEvent e) -> {
			gameService.handleBoardPositionSelection(boardPosition);
			moveSelectedWorkerGui();
		};
	}
	
	@Override
	public void moveWorkerToSelectedPosition(Worker worker, BoardPosition position) {
		// TODO Auto-generated method stub
		
	}

	private void moveSelectedWorkerGui() {
		moveSelectedWorkerGuiToTargetPosition();
		removeSelectedWorkerFromCurrentPlayerGui();
	}

	private void moveSelectedWorkerGuiToTargetPosition() {
		PlayerGuiControls currentPlayerGui = this.playersGui.getCurrentPlayerGui();
		Player currentPlayer = gameService.getCurrentPlayer();
		BoardPosition newPosition = currentPlayer.getSelectedWorker().getBoardPosition();
		int selectedWorkerIndex = currentPlayer.getSelectedWorkeIndex();
		WorkerGui selectedWorkerGui = currentPlayerGui.getWorkerGuiByIndex(selectedWorkerIndex);
		StackPane stackPane = boardGridArray[newPosition.getRow()][newPosition.getColumn()];
		stackPane.getChildren().add(selectedWorkerGui);
		markWorkerAsNotSelected(selectedWorkerGui);
	}

	private void removeSelectedWorkerFromCurrentPlayerGui() {
		Player currentPlayer = gameService.getCurrentPlayer();
		int selectedWorkerIndex = currentPlayer.getSelectedWorkeIndex();
		int currentPlayerIndex = gameService.getCurrentPlayerIndex();
		PlayerGuiControls currentPlayerGui = this.playerGuis[currentPlayerIndex];
		currentPlayerGui.getPlayerFlowPane().getChildren().remove(selectedWorkerIndex);
	}

	private EventHandler<MouseEvent> handleWorkerOnClick(Player player, PlayerGuiControls playerGui) {
		return (MouseEvent e) -> {
			WorkerGui workerGui = (WorkerGui) e.getSource();
			gameService.handleWorkerSelection(player, workerGui.getWorkerIndex());
			updateWorkersSelection(playerGui.getWorkers(), player.getWorkers());
		};
	}

	private void updateWorkersSelection(WorkerGui[] guiWorkers, Worker[] workers) {
		for (int index = 0; index < workers.length; index++) {
			Worker worker = workers[index];
			if (worker.isSelected()) {
				markWorkerAsSelected(guiWorkers[index]);
			} else {
				markWorkerAsNotSelected(guiWorkers[index]);
			}
		}
	}

	private void markWorkerAsNotSelected(WorkerGui workerGui) {
		System.out.println("Mark worker as not selected!");
		workerGui.getStrokeDashArray().clear();
		workerGui.setStrokeWidth(0);
	}

	private void markWorkerAsSelected(WorkerGui workerGui) {
		System.out.println("Mark worker as selected!");
		workerGui.setStroke(Color.BLACK);
		workerGui.getStrokeDashArray().addAll(5.0, 5.0, 5.0, 5.0);
		workerGui.setStrokeWidth(3);
	}

	@Override
	public void onPlayerMoveTargetPositionSelection() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onPlayerBuildingBlocSelection() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onPlayerBuildingBlocTargetPositionSelection() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onPlayerWorkerSelection(List<BoardPosition> possibleMovePositions) {
		if (possibleMovePositions != null) {
			markPossibleMovePositions(possibleMovePositions);
		}
	}

	private void markPossibleMovePositions(List<BoardPosition> possibleMovePositions) {
		// TODO Auto-generated method stub

	}

	@Override
	public void displayErrorMessage(String message) {
		messageToPlayer.setText(String.format("ERROR-MESSAGE: &s", message));
	}

	@Override
	public void displayInfoMessage(String message) {
		messageToPlayer.setText(String.format("INFO-MESSAGE: &s", message));
	}

	@Override
	public void updatePossibleMovePositionsDisplay(List<BoardPosition> possibleMovePositions) {
		for (BoardPosition boardPosition : possibleMovePositions) {
			StackPane node = boardGridArray[boardPosition.getRow()][boardPosition.getColumn()];
			updateBoardPositionSelection(node);
		}

	}

	private void updateBoardPositionSelection(StackPane node) {
		Effect effect = node.getEffect();
		if (effect == null) {
			InnerShadow ds = new InnerShadow(20, Color.RED);
			node.setEffect(ds);
		} else {
			node.setEffect(null);
		}	
	}

}
