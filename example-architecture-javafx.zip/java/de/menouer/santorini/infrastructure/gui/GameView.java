package de.menouer.santorini.infrastructure.gui;

import java.util.List;

import de.menouer.santorini.businesslogic.contract.IGameService;
import de.menouer.santorini.businesslogic.contract.IGameView;
import de.menouer.santorini.businesslogic.contract.impl.GameServiceImpl;
import de.menouer.santorini.businesslogic.model.BoardPosition;
import de.menouer.santorini.businesslogic.model.GameBoard;
import de.menouer.santorini.businesslogic.model.Player;
import de.menouer.santorini.businesslogic.model.Worker;
import de.menouer.santorini.infrastructure.gui.piece.PieceFigureFatory;
import de.menouer.santorini.infrastructure.gui.piece.WorkerGui;
import de.menouer.santorini.infrastructure.gui.player.PlayerGui;
import de.menouer.santorini.infrastructure.gui.player.PlayersGui;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.Node;
import javafx.scene.control.TextArea;
import javafx.scene.effect.Effect;
import javafx.scene.effect.InnerShadow;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;

public class GameView implements IGameView {
	
	private PlayersGui playersGui;

	@FXML
	private GridPane gameBoardGridPane;

	@FXML
	private TextArea messageToPlayer;

	@FXML
	private FlowPane firstPlayerFlowPane;

	@FXML
	private FlowPane secondPlayerFlowPane;

	private IGameService gameService;

	private StackPane[][] boardGridArray;

	public GameView() {
		gameService = GameServiceImpl.getInstance();
		gameService.setGameView(this);
		playersGui = new PlayersGui();
	}

	/**
	 * Initializes the controller class. This method is automatically called after
	 * the fxml file has been loaded.
	 */
	@FXML
	private void initialize() {
		onInitGameView();
	}

	@Override
	public void onInitGameView() {
		initGameBoardArray();
		playersGui.initFirstPlayerGui(firstPlayerFlowPane);
		playersGui.initSecondPlayerGui(secondPlayerFlowPane);
		
		initWorkersFlowPane(gameService.getCurrentPlayer(), playersGui.getCurrentPlayerGui());
		initWorkersFlowPane(gameService.getOtherPlayer(), playersGui.getOtherPlayerGui());
		
		markPlayerGuiAsSelected();
		
		markPossibleMovePositions(gameService.findPossibleInitialMovePositionsForWorker());
		
	}
	
	private void markPlayerGuiAsSelected() {
		PlayerGui currentPlayerGui = playersGui.getCurrentPlayerGui();
		FlowPane playerFlowPane = currentPlayerGui.getPlayerFlowPane();
		playerFlowPane.setStyle("-fx-border-color:black;-fx-border-width:4;-fx-border-style: segments(10, 5, 10, 5)  line-cap round ;");
		FlowPane otherPlayerFlowPane = playersGui.getOtherPlayerGui().getPlayerFlowPane();
		otherPlayerFlowPane.setStyle("-fx-border-color:black;-fx-border-width:2");
		
		markWorkerAsSelected(currentPlayerGui.getFirstWorker());
		markWorkerAsSelected(currentPlayerGui.getSecondWorker());
	}

	private void initWorkersFlowPane(Player player, PlayerGui playerGui) {
		WorkerGui firstWorker = PieceFigureFatory.createWorkerWithColor("First-Worker", Color.valueOf(player.getWorkerColor().name()));
		WorkerGui secondWorker = PieceFigureFatory.createWorkerWithColor("Second-Worker", Color.valueOf(player.getWorkerColor().name()));

		firstWorker.setOnMouseClicked(handleWorkerOnClick(player, playerGui, player.getFirstWorker()));
		secondWorker.setOnMouseClicked(handleWorkerOnClick(player, playerGui, player.getSecondWorker()));
		FlowPane playerFlowPane = playerGui.getPlayerFlowPane();
		playerGui.setFirstWorker(firstWorker);
		playerGui.setSecondWorker(secondWorker);
		playerFlowPane.getChildren().addAll(firstWorker, secondWorker);
	}

	private void initGameBoardArray() {
		this.boardGridArray = new StackPane[GameBoard.DIMENSION][GameBoard.DIMENSION];
		int rowIndex = 0;
		int colIndex = 0;
		for (Node node : this.gameBoardGridPane.getChildren()) {
			boardGridArray[rowIndex][colIndex] = (StackPane)node;
			node.setOnMouseClicked( handleGameBoardPositionOnClick( new BoardPosition(rowIndex, colIndex) ) );
			
			colIndex++;
			if (colIndex == GameBoard.DIMENSION) {
				colIndex = 0;
				rowIndex++;
			}
		}
	}

	private EventHandler<? super MouseEvent> handleGameBoardPositionOnClick(BoardPosition boardPosition) {
		return (MouseEvent e) -> {
			gameService.handleBoardPositionSelection(boardPosition);
		};
	}
	
	@Override
	public void moveWorkerToSelectedPosition(Worker worker, BoardPosition position) {
		moveSelectedWorkerGuiToTargetPosition(position);
		removeSelectedWorkerFromCurrentPlayerGui();
		markWorkerAsNotSelected(playersGui.getCurrentPlayerGui().getSelectedWorkerGui());
	}

	private void moveSelectedWorkerGuiToTargetPosition(BoardPosition position) {
		WorkerGui selectedWorkerGui = playersGui.getCurrentPlayerGui().getSelectedWorkerGui();
		StackPane stackPane = boardGridArray[position.getRow()][position.getColumn()];
		stackPane.getChildren().add(selectedWorkerGui);
	}

	private void removeSelectedWorkerFromCurrentPlayerGui() {
		PlayerGui currentPlayerGui = playersGui.getCurrentPlayerGui();
		WorkerGui selectedWorkerGui = currentPlayerGui.getSelectedWorkerGui();
		currentPlayerGui.getPlayerFlowPane().getChildren().remove(selectedWorkerGui);
	}

	private EventHandler<MouseEvent> handleWorkerOnClick(Player player, PlayerGui playerGui, Worker worker) {
		return (MouseEvent e) -> {
			if (worker.isPlacedOnBoard()) {
				WorkerGui selectedWorkerGui = (WorkerGui) e.getSource();
				gameService.handleWorkerSelection(player, worker);
				updateWorkersSelection(playerGui, selectedWorkerGui);	
			}
		};
	}

	private void updateWorkersSelection(PlayerGui playerGui, WorkerGui selectedWorkerGui) {
		boolean oldStatus = selectedWorkerGui.isSelected();
		if (oldStatus) {
			selectedWorkerGui.setSelected(false);
		} else {
			selectedWorkerGui.setSelected(true);
			for (WorkerGui workerGui : playerGui.getWorkers()) {
				if (!workerGui.equals(selectedWorkerGui)) {
					workerGui.setSelected(false);
				}
			}
		}
	}

	private void markWorkerAsNotSelected(WorkerGui workerGui) {
		workerGui.setSelected(false);
		workerGui.getStrokeDashArray().clear();
		workerGui.setStrokeWidth(0);
	}

	private void markWorkerAsSelected(WorkerGui workerGui) {
		workerGui.setSelected(true);
		workerGui.setStroke(Color.BLACK);
		workerGui.getStrokeDashArray().addAll(5.0, 5.0, 5.0, 5.0);
		workerGui.setStrokeWidth(3);
	}

	@Override
	public void onPlayerMoveTargetPositionSelection() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onPlayerBuildingBlocSelection() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onPlayerBuildingBlocTargetPositionSelection() {
		// TODO Auto-generated method stub

	}

	@Override
	public void onPlayerWorkerSelection(List<BoardPosition> possibleMovePositions) {
		if (possibleMovePositions != null) {
			markPossibleMovePositions(possibleMovePositions);
		}
	}

	private void markPossibleMovePositions(List<BoardPosition> positions) {
		updatePossibleMovePositionsDisplay(positions);
	}

	@Override
	public void displayErrorMessage(String message) {
		messageToPlayer.setText(String.format("ERROR-MESSAGE: &s", message));
	}

	@Override
	public void displayInfoMessage(String message) {
		messageToPlayer.setText(String.format("INFO-MESSAGE: &s", message));
	}

//	@Override
//	public void updatePossibleMovePositionsDisplay(List<BoardPosition> possibleMovePositions) {
//		
//		for (Node node : gameBoardGridPane.getChildren()) {
//			updateBoardPositionSelection((StackPane)node);
//		}
//		
//		for (BoardPosition boardPosition : possibleMovePositions) {
//			StackPane node = boardGridArray[boardPosition.getRow()][boardPosition.getColumn()];
//			updateBoardPositionSelection(node);
//		}
//
//	}
	
	@Override
	public void updatePossibleMovePositionsDisplay(List<BoardPosition> possibleMovePositions) {
		
		for (Node node : gameBoardGridPane.getChildren()) {
			node.setEffect(null);
		}
		
		for (BoardPosition boardPosition : possibleMovePositions) {
			StackPane node = boardGridArray[boardPosition.getRow()][boardPosition.getColumn()];
			InnerShadow ds = new InnerShadow(20, Color.BLUE);
			node.setEffect(ds);
		}

	}

	@Override
	public void changePlayer() {
		playersGui.changePlayer();
		markPlayerGuiAsSelected();
	}
	

}
