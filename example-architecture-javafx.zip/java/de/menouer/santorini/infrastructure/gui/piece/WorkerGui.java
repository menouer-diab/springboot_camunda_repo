package de.menouer.santorini.infrastructure.gui.piece;

import javafx.scene.shape.Circle;

public class WorkerGui extends Circle {
	private int workerIndex;
	
	public void setWorkerIndex(int workerIndex) {
		this.workerIndex = workerIndex;
	}

	public int getWorkerIndex() {
		return workerIndex;
	}
}
