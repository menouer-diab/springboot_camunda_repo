package de.menouer.santorini.infrastructure.gui.player;

import de.menouer.santorini.infrastructure.gui.piece.WorkerGui;
import javafx.scene.layout.FlowPane;
import javafx.scene.shape.Circle;

public class PlayerGuiControls {
	
	private FlowPane playerFlowPane;
	private WorkerGui[] workers;
	
	public PlayerGuiControls() {
		workers = new WorkerGui[2];
	}

	public FlowPane getPlayerFlowPane() {
		return playerFlowPane;
	}

	public void setPlayerFlowPane(FlowPane playerFlowPane) {
		this.playerFlowPane = playerFlowPane;
	}

	public WorkerGui getFirstWorker() {
		return workers[0];
	}

	public void setFirstWorker(WorkerGui firstWorker) {
		workers[0] = firstWorker;
	}

	public WorkerGui getSecondWorker() {
		return workers[1];
	}

	public void setSecondWorker(WorkerGui secondWorker) {
		workers[1] = secondWorker;
	}

	public WorkerGui[] getWorkers() {
		return workers;
	}

	public WorkerGui getWorkerGuiByIndex(int index) {
		return workers[index];
	}

}
