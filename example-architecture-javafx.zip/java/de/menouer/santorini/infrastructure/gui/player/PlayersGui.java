package de.menouer.santorini.infrastructure.gui.player;

import java.util.ArrayList;
import java.util.List;

import javafx.scene.layout.FlowPane;

public class PlayersGui {
	
	private List<PlayerGuiControls> players;
	private int currentPlayerGuiIndex;
	private int otherPlayerGuiIndex;
	
	public PlayersGui() {
		players = new ArrayList<>(2);
		currentPlayerGuiIndex = 0;
		otherPlayerGuiIndex = 1;
	}

	public void initFirstPlayerGui(FlowPane playerFlowPane) {
		addPlayerGuiAtIndex(0, playerFlowPane);
	}

	public void initSecondPlayerGui(FlowPane playerFlowPane) {
		addPlayerGuiAtIndex(1, playerFlowPane);
	}
	
	private void addPlayerGuiAtIndex(int index, FlowPane playerFlowPane) {
		PlayerGuiControls player = new PlayerGuiControls();
		player.setPlayerFlowPane(playerFlowPane);
		players.add(index, player);
	}
	
	public PlayerGuiControls getFirstPlayerGui() {
		return players.get(0);
	}
	
	public PlayerGuiControls getSecondPlayerGui() {
		return players.get(1);
	}
	
	public PlayerGuiControls getCurrentPlayerGui() {
		return players.get(currentPlayerGuiIndex);
	}
	
	public PlayerGuiControls getOtherPlayerGui() {
		return players.get(otherPlayerGuiIndex);
	}
	
	public void changePlayer() {
		currentPlayerGuiIndex = (currentPlayerGuiIndex + 1) % 2;
		otherPlayerGuiIndex = (otherPlayerGuiIndex + 1) % 2;
	}
}
