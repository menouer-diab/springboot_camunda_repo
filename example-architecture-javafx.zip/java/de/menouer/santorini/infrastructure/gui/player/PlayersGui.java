package de.menouer.santorini.infrastructure.gui.player;

import java.util.ArrayList;
import java.util.List;

import javafx.scene.layout.FlowPane;

public class PlayersGui {
	
	private List<PlayerGui> players;
	private int currentPlayerGuiIndex;
	private int otherPlayerGuiIndex;
	
	public PlayersGui() {
		players = new ArrayList<>(2);
		currentPlayerGuiIndex = 0;
		otherPlayerGuiIndex = 1;
	}

	public void initFirstPlayerGui(FlowPane playerFlowPane) {
		addPlayerGuiAtIndex(0, playerFlowPane);
	}

	public void initSecondPlayerGui(FlowPane playerFlowPane) {
		addPlayerGuiAtIndex(1, playerFlowPane);
	}
	
	private void addPlayerGuiAtIndex(int index, FlowPane playerFlowPane) {
		PlayerGui player = new PlayerGui();
		player.setPlayerFlowPane(playerFlowPane);
		players.add(index, player);
	}
	
	public PlayerGui getFirstPlayerGui() {
		return players.get(0);
	}
	
	public PlayerGui getSecondPlayerGui() {
		return players.get(1);
	}
	
	public PlayerGui getCurrentPlayerGui() {
		return players.get(currentPlayerGuiIndex);
	}
	
	public PlayerGui getOtherPlayerGui() {
		return players.get(otherPlayerGuiIndex);
	}
	
	public void changePlayer() {
		currentPlayerGuiIndex = (currentPlayerGuiIndex + 1) % 2;
		otherPlayerGuiIndex = (otherPlayerGuiIndex + 1) % 2;
	}
}
