package de.menouer.santorini.infrastructure.gui.player;

import java.util.Arrays;

import de.menouer.santorini.businesslogic.model.Player;
import de.menouer.santorini.infrastructure.gui.piece.WorkerGui;
import javafx.scene.layout.FlowPane;

public class PlayerGui {
	
	private FlowPane playerFlowPane;
	private WorkerGui[] workers;
	
	public PlayerGui() {
		workers = new WorkerGui[2];
	}

	public FlowPane getPlayerFlowPane() {
		return playerFlowPane;
	}

	public void setPlayerFlowPane(FlowPane playerFlowPane) {
		this.playerFlowPane = playerFlowPane;
	}

	public WorkerGui getFirstWorker() {
		return workers[0];
	}

	public void setFirstWorker(WorkerGui firstWorker) {
		workers[0] = firstWorker;
	}

	public WorkerGui getSecondWorker() {
		return workers[1];
	}

	public void setSecondWorker(WorkerGui secondWorker) {
		workers[1] = secondWorker;
	}

	public WorkerGui[] getWorkers() {
		return workers;
	}

	public WorkerGui getSelectedWorkerGui() {
		return Arrays.stream(workers).filter(worker -> worker.isSelected()).findFirst().get();
	}

}
