package de.menouer.santorini.main;

import de.menouer.santorini.infrastructure.console.main.ConsoleMain;
import de.menouer.santorini.infrastructure.gui.main.GuiMain;

public class SantoriniGame {

	public static final boolean GUI_MODUS = true;

	public static void main(String[] args) {
		// Application.launch(Gui.class, args);
		if (GUI_MODUS) {
			GuiMain gui = new GuiMain();
			gui.startGame(args);
		} else {
			ConsoleMain console = new ConsoleMain();
			console.startGame();
		}
	}

}
