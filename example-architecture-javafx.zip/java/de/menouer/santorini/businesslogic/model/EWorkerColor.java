package de.menouer.santorini.businesslogic.model;

public enum EWorkerColor {
	PURPLE, BLUE, RED,

}
