package de.menouer.santorini.businesslogic.model;

public class GameBoardCell {
	
	private boolean isFree;
	private BuildingBloc levelOneBloc;
	private BuildingBloc levelTwoBloc;
	private BuildingBloc levelThreeBloc;
	private BuildingBloc domBloc;
	private Worker worker;
	private BoardPosition position;
	
	public GameBoardCell(int rowIndex, int colIndex) {
		isFree = true;
		this.position = new BoardPosition(rowIndex, colIndex);
	}
	
	public boolean isFree() {
		return isFree;
	}
	
	public void setFree(boolean isFree) {
		this.isFree = isFree;
	}

	public BoardPosition getPosition() {
		return position;
	}

	public void setPosition(BoardPosition position) {
		this.position = position;
	}

	public Worker getWorker() {
		return worker;
	}

	public int getHighestBuildingBlocLevel() {
		// TODO Auto-generated method stub
		return 0;
	}
	

}
