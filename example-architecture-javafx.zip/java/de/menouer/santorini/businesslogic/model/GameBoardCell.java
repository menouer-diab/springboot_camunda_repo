package de.menouer.santorini.businesslogic.model;

public class GameBoardCell {

	private BuildingBloc levelOneBloc;
	private BuildingBloc levelTwoBloc;
	private BuildingBloc levelThreeBloc;
	private BuildingBloc domBloc;
	private Worker hostedWorker;
	private BoardPosition position;
	private int highestBuildingBlocLevel;

	public GameBoardCell(int rowIndex, int colIndex) {
		highestBuildingBlocLevel = 0;
		this.position = new BoardPosition(rowIndex, colIndex);
	}

	public boolean isFree() {
		return isFreeForLevel(0);
	}

	public boolean isFreeForLevel(int workerLevel) {
		return (hostedWorker == null) || (highestBuildingBlocLevel - workerLevel <= 1) || (domBloc == null);
	}

	public BoardPosition getPosition() {
		return position;
	}

	public void setPosition(BoardPosition position) {
		this.position = position;
	}

	public Worker getHostedWorker() {
		return hostedWorker;
	}

	public void setHostedWorker(Worker worker) {
		this.hostedWorker = worker;
	}

	public boolean isFreeForBuildingBloc(BuildingBloc buildingBloc) {
		return (hostedWorker == null) || (buildingBloc.getLevel() - highestBuildingBlocLevel == 1) || (domBloc == null);
	}

	public void addBuildingBloc(BuildingBloc buildingBloc) {
		switch (buildingBloc.getLevel()) {
		case 1:
			levelOneBloc = buildingBloc;
			break;

		case 2:
			levelTwoBloc = buildingBloc;
			break;

		case 3:
			levelThreeBloc = buildingBloc;
			break;
		case 4:
			domBloc = buildingBloc;
			break;
		}
	}

	public int getHighestBuildingBlocLevel() {
		return highestBuildingBlocLevel;
	}

}
