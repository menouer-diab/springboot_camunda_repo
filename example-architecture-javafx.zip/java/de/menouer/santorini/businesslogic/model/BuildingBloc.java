package de.menouer.santorini.businesslogic.model;

public class BuildingBloc {
	private int level;

	public BuildingBloc(int level) {
		super();
		this.level = level;
	}

	public int getLevel() {
		return level;
	}
}
