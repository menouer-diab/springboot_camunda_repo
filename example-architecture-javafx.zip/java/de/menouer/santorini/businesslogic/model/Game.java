package de.menouer.santorini.businesslogic.model;

import java.util.LinkedList;
import java.util.List;

public class Game {
	
	private GameBoard gameBoard;
	private List<Player> players;
	private int playerIndex;
	private GameSettings gameSettings;
	private GameNextAction nextAction;
	
	public Game() {
		gameBoard = new GameBoard();
		players = new LinkedList<>();
		playerIndex = 0;
	}

	public GameBoard getGameBoard() {
		return gameBoard;
	}

	public Player getCurrentPlayer() {
		return players.get(playerIndex);
	}

	public Player getOtherPlayer() {
		return playerIndex == 0 ? players.get(1):players.get(0);
	}

	public GameNextAction getNextAction() {
		return nextAction;
	}

	public void setNextAction(GameNextAction nextAction) {
		this.nextAction = nextAction;
	}

	public void setGameSettings(GameSettings gameSettings) {
		this.gameSettings = gameSettings;
	}

	public GameSettings getGameSettings() {
		return gameSettings;
	}

	public void setFirstPlayer(Player player) {
		players.add(0, player);
	}

	public void setSecondPlayer(Player player) {
		players.add(1, player);
	}

	public Player getFirstPlayer() {
		return players.get(0);
	}

	public Player getSecondPlayer() {
		return players.get(1);
	}

	public int getCurrentPlayerIndex() {
		return playerIndex;
	}
	
	public void changePlayer() {
		playerIndex = (playerIndex + 1) % 2;
	}


}
