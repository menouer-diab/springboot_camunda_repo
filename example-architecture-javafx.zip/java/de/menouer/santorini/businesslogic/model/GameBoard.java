package de.menouer.santorini.businesslogic.model;

import java.util.List;
import java.util.stream.IntStream;

public class GameBoard {
	public static final int DIMENSION = 5;
	private GameBoardCell[][] cellsArray;
	
	public GameBoard() {
		cellsArray = new GameBoardCell[DIMENSION][DIMENSION];
		IntStream.range(0, DIMENSION).forEach(rowIndex -> populateRow(rowIndex));
	}

	private void populateRow(int rowIndex) {
		IntStream.range(0, DIMENSION).forEach(colIndex -> populateRowColumn(rowIndex, colIndex));
	}

	private GameBoardCell populateRowColumn(int rowIndex, int colIndex) {
		return cellsArray[rowIndex][colIndex] = new GameBoardCell(rowIndex, colIndex);
	}
	
	public GameBoardCell[][] getCellsArray() {
		return cellsArray;
	}

	public List<BoardPosition> getNeighbourPositions(BoardPosition boardPosition) {
		return null;
	}
}
