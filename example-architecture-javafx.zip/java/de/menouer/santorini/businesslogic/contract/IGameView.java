package de.menouer.santorini.businesslogic.contract;

import java.util.List;

import de.menouer.santorini.businesslogic.model.BoardPosition;
import de.menouer.santorini.businesslogic.model.Worker;

public interface IGameView {
	
	void onInitGameView();
		
	void onPlayerMoveTargetPositionSelection();
	
	void onPlayerBuildingBlocSelection();
	
	void onPlayerBuildingBlocTargetPositionSelection();

	void onPlayerWorkerSelection(List<BoardPosition> possibleMovePositions);

	void displayErrorMessage(String message);

	void displayInfoMessage(String message);

	void updatePossibleMovePositionsDisplay(List<BoardPosition> possibleMovePositions);

	void moveWorkerToSelectedPosition(Worker worker, BoardPosition position);

}
