package de.menouer.santorini.businesslogic.contract.impl;

import java.util.LinkedList;
import java.util.List;

import de.menouer.santorini.businesslogic.contract.IGameService;
import de.menouer.santorini.businesslogic.contract.IGameSettingsView;
import de.menouer.santorini.businesslogic.contract.IGameView;
import de.menouer.santorini.businesslogic.model.BoardPosition;
import de.menouer.santorini.businesslogic.model.Game;
import de.menouer.santorini.businesslogic.model.GameBoard;
import de.menouer.santorini.businesslogic.model.GameBoardCell;
import de.menouer.santorini.businesslogic.model.GameNextAction;
import de.menouer.santorini.businesslogic.model.GameSettings;
import de.menouer.santorini.businesslogic.model.Player;
import de.menouer.santorini.businesslogic.model.Worker;

public class GameServiceImpl implements IGameService {

	private Game game;
	private IGameView view;
	private IGameSettingsView settingsView;
	private static IGameService gameService;

	// private GameBoard gameBoard;

	private GameServiceImpl() {
		initGame();
	}

	private GameServiceImpl(IGameView view) {
		this();
		this.view = view;
	}

	public static synchronized IGameService getInstance() {
		if (gameService == null) {
			gameService = new GameServiceImpl();
		}
		return gameService;
	}

	public static synchronized IGameService getInstance(IGameView view) {
		if (gameService == null) {
			gameService = new GameServiceImpl(view);
		}
		return gameService;
	}

	@Override
	public void setSettingsView(IGameSettingsView settingsView) {
		this.settingsView = settingsView;
	}

	@Override
	public void setGameView(IGameView gameView) {
		this.view = gameView;
	}

	@Override
	public void initGame() {
		game = new Game();
		game.setNextAction(GameNextAction.GET_PLAYERS_SETTINGS);
	}

	@Override
	public void startGame() {
		// TODO Auto-generated method stub

	}

	@Override
	public void getPossibleBuildingBlocsForPlayer() {
		// TODO Auto-generated method stub

	}

	@Override
	public void checkPlayerSelectedBuildingBloc() {
		// TODO Auto-generated method stub

	}

	public GameBoard getGameBoard() {
		return game.getGameBoard();
	}

	@Override
	public Player getCurrentPlayer() {
		return game.getCurrentPlayer();
	}

	@Override
	public Player getOtherPlayer() {
		return game.getOtherPlayer();
	}

	@Override
	public void checkPlayerMove(Player currentPlayer, BoardPosition position) {
		// TODO Auto-generated method stub

	}

	@Override
	public void handleBoardPositionSelection(BoardPosition selectedPosition) {
		switch (game.getNextAction()) {

		case SELECT_PLAYER_FIRST_WORKER_INITIAL_POSITION:
			Worker firstWorker = getCurrentPlayer().getFirstWorker();
			movePlayerWorkerToSelectedPosition(firstWorker, selectedPosition);
			game.setNextAction(GameNextAction.SELECT_PLAYER_SECOND_WORKER_INITIAL_POSITION);
			
			List<BoardPosition> allowedPositions = findPossibleInitialMovePositionsForWorker();
			view.updatePossibleMovePositionsDisplay(allowedPositions);
			
			break;

		case SELECT_PLAYER_SECOND_WORKER_INITIAL_POSITION:
			Worker secondWorker = getCurrentPlayer().getSecondWorker();
			movePlayerWorkerToSelectedPosition(secondWorker, selectedPosition);
			
			if (getOtherPlayer().isOnGameBoard()) {
				game.setNextAction(GameNextAction.SELECT_PLAYER_BUILDING_BLOC);
			} else {
				game.setNextAction(GameNextAction.SELECT_PLAYER_FIRST_WORKER_INITIAL_POSITION);
				allowedPositions = findPossibleInitialMovePositionsForWorker();
				view.updatePossibleMovePositionsDisplay(allowedPositions);
			}
			
			game.changePlayer();
			view.changePlayer();
			break;

		case CHECK_PLAYER_MOVE_POSITION_SELECTION:
			break;

		case CHECK_PLAYER_BUILDING_POSITION_SELECTION:
			break;

		default:
		}

	}

	private void movePlayerWorkerToSelectedPosition(Worker worker, BoardPosition position) {
		if (isWorkerMovePossible(worker, position)) {
			worker.setBoardPosition(position);
			this.game.getGameBoard().getCellsArray()[position.getRow()][position.getColumn()].setHostedWorker(worker);
			view.moveWorkerToSelectedPosition(worker, position);
		} else {
			view.displayErrorMessage(
					"The position you selected for your worker is neither free nor hosting a compatible building-bloc level!");
		}
	}

	private boolean isWorkerMovePossible(Worker worker, BoardPosition position) {
		List<BoardPosition> possibleMovePositions = (worker.isPlacedOnBoard())
				? findPossibleNeighbourMovePositionsForWorker(worker)
				: findPossibleInitialMovePositionsForWorker();
		return possibleMovePositions.contains(position);
	}

	private List<BoardPosition> findPossibleNeighbourMovePositionsForWorker(Worker worker) {
		List<BoardPosition> possibleMovePositions = new LinkedList<>();
		GameBoard gameBoard = getGameBoard();
		GameBoardCell[][] cellsArray = gameBoard.getCellsArray();
		// check only neighbourPositions
		List<BoardPosition> neighbourPositions = gameBoard.getNeighbourPositions(worker.getBoardPosition());
		for (BoardPosition neighbour : neighbourPositions) {
			if (cellsArray[neighbour.getRow()][neighbour.getColumn()].isFreeForLevel(worker.getLevel())) {
				possibleMovePositions.add(neighbour);
			}
		}
		return possibleMovePositions;
	}

	@Override
	public List<BoardPosition> findPossibleInitialMovePositionsForWorker() {
		List<BoardPosition> possibleMovePositions = new LinkedList<>();
		GameBoard gameBoard = getGameBoard();
		GameBoardCell[][] cellsArray = gameBoard.getCellsArray();
		for (int rowIndex = 0; rowIndex < GameBoard.DIMENSION; rowIndex++) {
			for (int colIndex = 0; colIndex < GameBoard.DIMENSION; colIndex++) {
				if (cellsArray[rowIndex][colIndex].isFree()) {
					possibleMovePositions.add(new BoardPosition(rowIndex, colIndex));
				}
			}
		}
		return possibleMovePositions;
	}

	@Override
	public void handleGameSettingsOnSubmit(GameSettings gameSettings) {
		if (isValid(gameSettings)) {
			game.setGameSettings(gameSettings);
			Player firstPlayer = new Player(gameSettings.getFirstPlayerName(),
					gameSettings.getFirstPlayerWorkerColor());
			Player secondPlayer = new Player(gameSettings.getSecondPlayerName(),
					gameSettings.getSecondPlayerWorkerColor());
			game.setFirstPlayer(firstPlayer);
			game.setSecondPlayer(secondPlayer);
			game.setNextAction(GameNextAction.SELECT_PLAYER_FIRST_WORKER_INITIAL_POSITION);
			settingsView.startGame();
		} else {
			settingsView
					.displayGameSettingsErrorMessage("Settings entered are not valid. Please set the settings again!");
		}
	}

	private boolean isValid(GameSettings gameSettings) {

		if (gameSettings.getFirstPlayerName() == null || gameSettings.getFirstPlayerName().length() == 0) {
			return false;
		}

		if (gameSettings.getSecondPlayerName() == null || gameSettings.getSecondPlayerName().length() == 0) {
			return false;
		}

		if (gameSettings.getFirstPlayerName().equals(gameSettings.getSecondPlayerName())) {
			return false;
		}

		if (gameSettings.getFirstPlayerWorkerColor().equals(gameSettings.getSecondPlayerWorkerColor())) {
			return false;
		}

		return true;

	}

	@Override
	public List<BoardPosition> handleWorkerSelection(Player player, Worker worker) {

		updateWorkersSelectionState(player, worker);

		List<BoardPosition> possibleMovePositions = null;

		switch (game.getNextAction()) {

		case SELECT_PLAYER_FIRST_WORKER_INITIAL_POSITION:

			break;

		case WORKER_TO_BE_MOVED_SELECTION:
			possibleMovePositions = findPossibleInitialMovePositionsForWorker();
			view.updatePossibleMovePositionsDisplay(possibleMovePositions);
			game.setNextAction(GameNextAction.CHECK_PLAYER_MOVE_POSITION_SELECTION);
			break;

		case CHECK_PLAYER_MOVE_POSITION_SELECTION:

			break;

		case CHECK_PLAYER_BUILDING_POSITION_SELECTION:
			break;

		default:
		}

		return possibleMovePositions;
	}

	private void updateWorkersSelectionState(Player player, Worker worker) {
		if (worker.isSelected()) {
			worker.setSelected(false);
		} else {
			// Mark previously possible selected workers as not selected.
			Worker selectedWorker = player.getSelectedWorker();
			if (selectedWorker != null && selectedWorker != worker) {
				selectedWorker.setSelected(false);
			}
			// update selection status!
			worker.setSelected(true);
		}
	}

}
