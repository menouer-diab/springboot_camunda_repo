package de.menouer.santorini.businesslogic.contract.impl;

import java.util.LinkedList;
import java.util.List;

import de.menouer.santorini.businesslogic.contract.IGameService;
import de.menouer.santorini.businesslogic.contract.IGameSettingsView;
import de.menouer.santorini.businesslogic.contract.IGameView;
import de.menouer.santorini.businesslogic.model.BoardPosition;
import de.menouer.santorini.businesslogic.model.Game;
import de.menouer.santorini.businesslogic.model.GameBoard;
import de.menouer.santorini.businesslogic.model.GameBoardCell;
import de.menouer.santorini.businesslogic.model.GameNextAction;
import de.menouer.santorini.businesslogic.model.GameSettings;
import de.menouer.santorini.businesslogic.model.Player;
import de.menouer.santorini.businesslogic.model.Worker;

public class GameServiceImpl implements IGameService {

	private Game game;
	private IGameView view;
	private IGameSettingsView settingsView;
	private static IGameService gameService;

	// private GameBoard gameBoard;

	private GameServiceImpl() {
		initGame();
	}

	private GameServiceImpl(IGameView view) {
		this();
		this.view = view;
	}

	public static synchronized IGameService getInstance() {
		if (gameService == null) {
			gameService = new GameServiceImpl();
		}
		return gameService;
	}

	public static synchronized IGameService getInstance(IGameView view) {
		if (gameService == null) {
			gameService = new GameServiceImpl(view);
		}
		return gameService;
	}

	@Override
	public void setSettingsView(IGameSettingsView settingsView) {
		this.settingsView = settingsView;
	}

	@Override
	public void setGameView(IGameView gameView) {
		this.view = gameView;
	}

	@Override
	public void initGame() {
		game = new Game();
		game.setNextAction(GameNextAction.GET_PLAYERS_SETTINGS);
	}

	@Override
	public void startGame() {
		// TODO Auto-generated method stub

	}

	@Override
	public List<BoardPosition> findPossibleMovePositionsForPlayer() {
		
		List<BoardPosition> possibleMovePositions = new LinkedList<>();
		
		GameBoard gameBoard = this.getGameBoard();
		
		GameBoardCell[][] cellsArray = gameBoard.getCellsArray();
		
		for (int rowIndex = 0; rowIndex < GameBoard.DIMENSION; rowIndex++) {
			for (int colIndex = 0; colIndex < GameBoard.DIMENSION; colIndex++) {
				if (cellsArray[rowIndex][colIndex].isFree()) {
					possibleMovePositions.add(new BoardPosition(rowIndex, colIndex));
				}
			}
		}
		
		return possibleMovePositions;
	}

	@Override
	public void getPossibleBuildingBlocsForPlayer() {
		// TODO Auto-generated method stub

	}

	@Override
	public void checkPlayerSelectedBuildingBloc() {
		// TODO Auto-generated method stub

	}

	public GameBoard getGameBoard() {
		return game.getGameBoard();
	}

	@Override
	public Player getCurrentPlayer() {
		return game.getCurrentPlayer();
	}

	@Override
	public Player getOtherPlayer() {
		return game.getOtherPlayer();
	}

	@Override
	public void checkPlayerMove(Player currentPlayer, BoardPosition position) {
		// TODO Auto-generated method stub

	}

	@Override
	public void handleBoardPositionSelection(BoardPosition selectedPosition) {
		switch (game.getNextAction()) {

		case WORKER_TO_BE_MOVED_SELECTION:
			break;

		case CHECK_WORKER_INITIAL_POSITION_SELECTION:
			break;

		case CHECK_PLAYER_MOVE_POSITION_SELECTION:
			handleGameBoardPositionSelection(selectedPosition);
			break;

		case CHECK_PLAYER_BUILDING_POSITION_SELECTION:
			break;

		default:
		}

	}

	private void handleWorkerInitialPositionSelection(BoardPosition selectedPosition) {
		GameBoard gameBoard = game.getGameBoard();
		GameBoardCell gameBoardCell = gameBoard.getCellsArray()[selectedPosition.getRow()][selectedPosition
				.getColumn()];
		int highestBuildingBlocLevel = gameBoardCell.getHighestBuildingBlocLevel();

		if (gameBoardCell.isFree() || highestBuildingBlocLevel == 1) {
			Player currentPlayer = game.getCurrentPlayer();
			Worker selectedWorker = currentPlayer.getSelectedWorker();
			
			selectedWorker.setSelected(false);
			selectedWorker.setPosition(selectedPosition);

			if (currentPlayer.hasAllWorkersPlacedOnBoard()) {

			} else {
				game.setNextAction(GameNextAction.WORKER_TO_BE_MOVED_SELECTION);
			}

			view.displayInfoMessage("successful initial position selection for worker!");
			return;
		} else {
			view.displayErrorMessage("worker isn't allowed to be placed on a building-bloc level greater than 1!");
		}

	}

	private void handleWorkerToBeMovedSelection(BoardPosition selectedPosition) {
		GameBoard gameBoard = game.getGameBoard();
		GameBoardCell gameBoardCell = gameBoard.getCellsArray()[selectedPosition.getRow()][selectedPosition
				.getColumn()];
		Worker worker = gameBoardCell.getWorker();
		if (worker != null) {
			if (game.getCurrentPlayer().owns(worker)) {
				game.setNextAction(GameNextAction.CHECK_PLAYER_MOVE_POSITION_SELECTION);
				List<BoardPosition> possibleMovesForPlayer = findPossibleMovePositionsForPlayer();
				worker.setSelected(true);
				view.onPlayerWorkerSelection(possibleMovesForPlayer);
				view.displayInfoMessage("succesful Worker selection!");
			} else {
				view.displayErrorMessage("The worker you selected doesn't belong to the current player!");
			}
		} else {
			view.displayErrorMessage("there exists no worker on the selected board position!");
		}
	}

	@Override
	public void handleGameSettingsOnSubmit(GameSettings gameSettings) {
		if (isValid(gameSettings)) {
			game.setGameSettings(gameSettings);
			game.setFirstPlayer(new Player(gameSettings.getFirstPlayerName(), gameSettings.getFirstPlayerWorkerColor()));
			game.setSecondPlayer(new Player(gameSettings.getSecondPlayerName(), gameSettings.getSecondPlayerWorkerColor()));
			game.setNextAction(GameNextAction.WORKER_TO_BE_MOVED_SELECTION);
			settingsView.startGame();
		} else {
			settingsView.displayGameSettingsErrorMessage("Settings entered are not valid. Please set the settings again!");
		}
	}

	private boolean isValid(GameSettings gameSettings) {

		if (gameSettings.getFirstPlayerName() == null || gameSettings.getFirstPlayerName().length() == 0) {
			return false;
		}

		if (gameSettings.getSecondPlayerName() == null || gameSettings.getSecondPlayerName().length() == 0) {
			return false;
		}

		if (gameSettings.getFirstPlayerName().equals(gameSettings.getSecondPlayerName())) {
			return false;
		}

		if (gameSettings.getFirstPlayerWorkerColor().equals(gameSettings.getSecondPlayerWorkerColor())) {
			return false;
		}

		return true;

	}

	@Override
	public List<BoardPosition> handleWorkerSelection(Player player, int workerIndex) {
		
		updateWorkersSelectionState(player, workerIndex);
		
		List<BoardPosition> possibleMovePositions = null;
		
		switch (game.getNextAction()) {

		case CHECK_WORKER_INITIAL_POSITION_SELECTION:
			
			break;
			
		case WORKER_TO_BE_MOVED_SELECTION:
			possibleMovePositions = findPossibleMovePositionsForPlayer();
			view.updatePossibleMovePositionsDisplay(possibleMovePositions);
			game.setNextAction(GameNextAction.CHECK_PLAYER_MOVE_POSITION_SELECTION);
			break;


		case CHECK_PLAYER_MOVE_POSITION_SELECTION:
			
			break;

		case CHECK_PLAYER_BUILDING_POSITION_SELECTION:
			break;

		default:
		}
		
		return possibleMovePositions;
	}

	private void updateWorkersSelectionState(Player player, int workerIndex) {
		
		Worker worker = player.getWorker(workerIndex);
		boolean currentStatus = worker.isSelected();
		
		// Mark previously possible selected worker as not selected.
		Worker selectedWorker = player.getSelectedWorker();
		if (selectedWorker != null && selectedWorker != worker) {
			selectedWorker.setSelected(false);
		}
		
		// update selection status!
		worker.setSelected(!currentStatus);
	}

	private void handleGameBoardPositionSelection(BoardPosition boardPosition) {
		if (game.getNextAction() == GameNextAction.CHECK_PLAYER_MOVE_POSITION_SELECTION) {
			List<BoardPosition> possibleMovePositions = findPossibleMovePositionsForPlayer();
			if (possibleMovePositions.contains(boardPosition)) {
				// valid position selection
				moveSelectedWorkerToPosition(boardPosition);
			} else {
				view.displayErrorMessage("This Game-Board Position is not allowed to be selected!");
			}
		}
	}

	private void moveSelectedWorkerToPosition(BoardPosition boardPosition) {
		Worker selectedWorker = getCurrentPlayer().getSelectedWorker();
		selectedWorker.setPosition(boardPosition);
	}

	@Override
	public int getCurrentPlayerIndex() {
		return this.game.getCurrentPlayerIndex();
	}

}
