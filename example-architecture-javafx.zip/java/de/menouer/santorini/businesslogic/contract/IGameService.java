package de.menouer.santorini.businesslogic.contract;

import java.util.List;

import de.menouer.santorini.businesslogic.model.BoardPosition;
import de.menouer.santorini.businesslogic.model.GameBoard;
import de.menouer.santorini.businesslogic.model.GameSettings;
import de.menouer.santorini.businesslogic.model.Player;
import de.menouer.santorini.businesslogic.model.Worker;

public interface IGameService {
	
	void initGame();

	void startGame();

	List<BoardPosition> findPossibleInitialMovePositionsForWorker();

	void getPossibleBuildingBlocsForPlayer();

	void checkPlayerMove(Player currentPlayer, BoardPosition position);

	void checkPlayerSelectedBuildingBloc();

	GameBoard getGameBoard();

	Player getCurrentPlayer();
	
	Player getOtherPlayer();

	void handleBoardPositionSelection(BoardPosition selectedPosition);

	void setSettingsView(IGameSettingsView settingsView);

	void setGameView(IGameView gameView);

	void handleGameSettingsOnSubmit(GameSettings gameSettings);

	List<BoardPosition> handleWorkerSelection(Player player, Worker worker);	
}
