package de.menouer.santorini.businesslogic.contract;

public interface IGameSettingsView {
	
	void gameSettingsOnSubmit();

	void displayGameSettingsErrorMessage(String errorMessage);

	void startGame();
}
